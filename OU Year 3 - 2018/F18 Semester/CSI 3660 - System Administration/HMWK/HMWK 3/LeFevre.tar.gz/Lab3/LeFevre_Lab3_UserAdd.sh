#!/bin/bash

# Read and parse a CSV file in Bash

INFILE=USERS.csv
OLDIFS=$IFS

IFS=,
[ ! -f $INFILE ] && { echo "$INFILE file not found"; exit 99; }
while read username fname lname grp
do
	echo "Username : $username"
	echo "Name : $fname $lname"
	echo "Group : $grp"

# Add user, assign user to a group and confirm
	sudo adduser $username
	echo "$username:temp12345" | sudo chpasswd
	sudo usermod -aG $grp $username
	groups $username

	echo "=========="
done < $INFILE
IFS=$OLDIFS
