#!/bin/bash

# Fabian LeFevre
# fjlefevre@oakland.edu
# 10/12/2018
# Removes the five users, their directories and confirms that they are
# The pwd confirms what the current directory is. If it wasn't able to move
# to one of the users' home directory, then they were properly deleted.

users=("user1" "user2" "user3" "user4" "user5")

for i in {0..4}
do
	echo ${users[$i]}

	sudo userdel -r ${users[$i]}
	groups ${users[$1]}
	cd /home/${users[$i]}
	pwd
done
