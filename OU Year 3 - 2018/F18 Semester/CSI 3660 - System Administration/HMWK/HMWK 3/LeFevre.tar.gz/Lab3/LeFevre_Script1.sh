#!/bin/bash

echo Hello $1, the contents of my home directory are: 
$3 /home/$2
