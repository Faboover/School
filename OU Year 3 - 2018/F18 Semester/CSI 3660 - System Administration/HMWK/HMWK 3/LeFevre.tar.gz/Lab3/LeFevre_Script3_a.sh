#!/bin/bash

# Fabian LeFevre
# fjlefevre@oakland.edu
# 10/12/2018
# Adds five users to the system and shows they were added

users=("user1" "user2" "user3" "user4" "user5")

for i in {0..4}
do
	echo ${users[$i]}

	sudo adduser ${users[$i]}
	groups ${users[$1]}
done
