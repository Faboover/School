#!/bin/bash

for i in {1..15}
do
echo $i % 2 = `expr $i % 2`
done
