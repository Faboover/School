﻿# Lab 3 - AD PowerSHell Basics
# Name: Fabian LeFevre
# Date: 2/7/2019
# Description: Read a congifured Names.txt file and add the list of users to AD and make them Admins if they are supposed to be.

$users = import-csv Names.txt

foreach ($user in $users)
{
    Write-Host -fore yellow $user.FirstName"" $user.LastName" : " $user.UserName" : " $user.StreetName" : " $user.PhoneNumber" : " $user.Email" : " $user.JobTitle" : " $user.Admin
}

Import-Module ActiveDirectory

foreach($user in $users)
{
    $ou = "CN=Users,DC=csi3670,DC=local"
    $pw = "Temp12345"
    $detailed_name = $user.FirstName + " " + $user.Lastname
    $firstletter_first_name = $user.FirstName.Substring(0,1)
    $SAM = $firstletter_first_name + $user.LastName

    $street = $user.StreetName
    $phone = $user.PhoneNumber
    $job = $user.JobTitle
    $email = $user.Email

    New-AdUser -Name $SAM -SamAccountName $SAM -UserPrincipalName $SAM -DisplayName $detailed_name -GivenName $user.FirstName -Surname $user.LastName -AccountPassword (ConvertTo-SecureString $pw -AsPlainText -Force) -StreetAddress $street -EmailAddress $email -HomePhone $phone -Title $job -Enabled $true -Path $ou

    if ($user.Admin -eq 1)
    {
        Add-ADGroupMember -Identity Administrators -Members $SAM
    }
}